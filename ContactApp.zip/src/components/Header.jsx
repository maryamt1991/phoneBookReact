import React from 'react'

function Header() {
    return (
        <div className='my-20 flex items-center justify-center flex-col gap-4'>
            <h1 className='font-bold text-2xl text-blue-600'>contact app</h1>
            <p><a href="www.pakoobrah.com" className='text-white bg-blue-600 px-4 py-2 rounded-lg hover:bg-blue-300 hover:text-gray-700'>pakoobrah</a>| protect nature </p>
        </div>
    )
}

export default Header
import React,{useState} from 'react'
import ContactList from './ContactList';
import inputs from '../constants/inputs';
import { v4 as uuidv4 } from 'uuid';

function Contacts() {
    
    const [contact,setContact]=useState({
        name:"",
        lastName:"",
        email:"",
        number:"",
        id:"",
    });
    const [contacts,setContacts]=useState([]);
    const [alert,setAlert]=useState("");
    const changeHandler=(event)=>{
const name=event.target.name;
const value=event.target.value;

setContact((contact)=>({...contact,[name]:value}))
    }
    const addHandler=()=>{
        if(!contact.name || !contact.lastName || !contact.email ||!contact.number){
            setAlert("please enter valid data!");
            return;
        }
        setAlert("");
        const newContact={...contact,id:uuidv4()}
        setContacts((contacts)=>[...contacts,newContact]);
        setContact({
            name:"",
            lastName:"",
            email:"",
            number:"",
        })
        console.log(contacts);
    }
    const deleteHandler=(id)=>{
        const newContacts=contacts.filter((contact)=>contact.id!==id);
        setContacts(newContacts);
    }
  return (
    <div>
        <div className='bg-blue-200 px-1 py-1 rounded-xl items-center justify-center flex flex-col gap-2'>
            <div className='grid grid-cols1 md:grid-cols-2 gap-2 w-full px-10 py-8'>
            {
                inputs.map((input , index)=>(<input className="rounded-xl px-2 py-2"key={index} type={input.type}
                     placeholder={input.placeholder} 
                     name={input.name} 
                     value={contact[input.name]} 
                     onChange={changeHandler}/>))
            }
            {/*
            <input type='text' placeholder='Name' value={contact.name}  onChange={changeHandler} name="name"/>
            <input type='text' placeholder='LastName' value={contact.lastName} onChange={changeHandler} name="lastName"/>
            <input type='email' placeholder='Email' value={contact.email} onChange={changeHandler} name="email"/>
            <input type='number' placeholder='PhoneNumber' value={contact.number} onChange={changeHandler} name="number"/>
            */}
            </div>
            <button onClick={addHandler} className='bg-blue-500 text-white rounded-xl px-3 py-2 mb-4 w-[50%]'>add contact</button>
        </div>
        <div className='text-red-600 font-bold'>{alert && <p>{alert}</p>}</div>
        <ContactList contacts={contacts} deleteHandler={deleteHandler}/>
    </div>
  )
}

export default Contacts
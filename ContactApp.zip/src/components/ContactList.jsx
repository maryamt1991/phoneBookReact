import React from 'react'
import ContactItem from './ContactItem'


function ContactList({contacts , deleteHandler}) {
  return (
    <div className='bg-gray-200 rounded-xl py-6 flex flex-col items-center justify-center mt-5'>
        <h2 className='font-bold text-blue-800'>ContactList</h2>
        {
            contacts.length ?(<ul className='flex flex-col w-full gap-4'>
                {
                    contacts.map((contact)=>(<ContactItem key={contact.id} data={contact} deleteHandler={deleteHandler}/>))
    
                }
            </ul>):<p>no contacts yet!</p>
        }
        
        </div>
  )
}

export default ContactList
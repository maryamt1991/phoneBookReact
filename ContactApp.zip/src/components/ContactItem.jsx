
function ContactItem({data:{id, name, lastName, email, number} , deleteHandler}) {
  return (
    <li key={id} className="grid grid-cols-4 gap-6 justify-center items-center px-3 py-2 bg-gray-400 mx-3 rounded-xl">
                        <p>{name} {lastName}</p>
                        <p>{email}</p>
                        <p>{number}</p>
                        <button className="bg-blue-600 rounded-lg text-white w-20" onClick={()=>deleteHandler(id)}>delete</button>
                        </li>)
  
}

export default ContactItem
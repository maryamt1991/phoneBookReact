const inputs=[
    {type:"text", name:"name", placeholder:"Name" },
    {type:"text", name:"lastName", placeholder:"LastName" },
    {type:"email", name:"email", placeholder:"Email" },
    {type:"number", name:"number", placeholder:"Number" },
];
export default inputs;